﻿ПРОШИВКА SANGABOARD v0.5 — для вас, заводу не нужна

openflexure-sangaboard-v1.0.4.uf2 — собрана из официального кода:
https://gitlab.com/openflexure/sangaboard/sangaboard-firmware (ветка release, коммит b729ab5, версия v1.0.4)
команда: pio run -e pico  (сборка pico = Sangaboard v0.5.x)
SHA-256: 51d5c261c1ce9216dff9305d1bac4d359c0cb167742683c46a5857dce665bc65

Как прошить:
1. Зажать кнопку USB_BOOT на плате и подключить её к компьютеру кабелем USB-C.
2. Отпустить кнопку — появится диск RPI-RP2.
3. Скопировать на него этот файл. Плата перезагрузится, диск исчезнет.
