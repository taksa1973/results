﻿ПАКЕТ ДЛЯ ЗАВОДА: платы для микроскопа OpenFlexure (проект ARGUS), по 1 штуке

ZAYAVKA-dlya-zavoda.txt — текст заявки, его можно вставить в письмо.

1-sangaboard-v0.5 — плата управления моторами и подсветкой Sangaboard v0.5, ОДНА плата
  gerbers.zip  — Gerber и сверловка (4 слоя, 65,1 × 56,6 мм; в проекте 1,6 мм, у Резонита типовая сборка 1,5 мм — подходит); отверстия: металлизированные — *-PTH.drl, без металлизации — *-NPTH.drl
  bom.csv      — компоненты с кодами магазина LCSC (74 позиции на плате)
  pos.csv      — координаты монтажа (формат JLCPCB)
  schematic.pdf, render.png — схема и вид платы
  kicad-ishodniki — исходный проект KiCad 7
  montazh-rezonit — файлы для монтажа в Резоните: спецификация (xlsx), сборочный чертёж (pdf), файл платы ODB++ (zip),
    требования к монтажу (docx), координаты (xlsx). bom.csv и pos.csv выше — формат JLCPCB (повороты под их библиотеку), Резониту не подходят.
  Источник: https://gitlab.com/openflexure/sangaboard/sangaboard-rp2040 (коммит 4ee3db9, v0.5.5c)

2-plata-svetodioda — плата светодиода подсветки (ofm-led), ОДНА плата
  gerbers.zip  — Gerber и сверловка (2 слоя, 11,2 × 15,0 мм, 1,6 мм); PTH и NPTH отдельными файлами
  bom.csv, pos.csv — светодиод Bridgelux BXEN-50S-11M-3C (C5271345) и разъём 1×2 (C492410)
  kicad-ishodniki — исходный проект KiCad 7
  Источник: https://gitlab.com/filipayazi/ofm-led (коммит 44d5851)

3-proshivka — прошивка для Sangaboard (заводу не нужна, прошьёте сами по README в папке)

Как получены файлы. В репозиториях проекта лежат только панели по нескольку плат.
Эти файлы сгенерированы из исходников той же командой, что у авторов, но без панели:
  kikit fab jlcpcb alt-sangaboard.kicad_pcb --assembly --schematic alt-sangaboard.kicad_sch --no-drc --field JLCPCB --corrections JLC_ROT out
  kikit fab jlcpcb --no-drc --assembly --schematic ofm_cc_illumination.kicad_sch ofm_cc_illumination.kicad_pcb out
(KiCad 7.0.11, KiKit 1.5.1). Сверловка разделена на PTH и NPTH через kicad-cli (абсолютные координаты, мм), точки совпадают с исходной. Состав компонентов и повороты Sangaboard совпадают с официальной панелью.
Из списка платы светодиода убран LOGO1 — это рисунок на шелкографии, не компонент.

Лицензии — файлы LICENSE / License в папках (Sangaboard — CERN-OHL-S v2, плата светодиода — CERN OHL v1.2, прошивка — GPLv3).
