﻿ПАКЕТ ДЛЯ ЗАВОДА: платы для микроскопа OpenFlexure (проект ARGUS)

ZAYAVKA-dlya-zavoda.txt — текст заявки, его можно вставить в письмо.

1-sangaboard-v0.5 — плата управления моторами и подсветкой Sangaboard v0.5
  gerbers.zip  — Gerber-файлы панели из 6 плат (4 слоя, 148,1 × 180,75 мм, 1,6 мм)
  bom.csv      — список компонентов с кодами магазина LCSC
  pos.csv      — координаты монтажа
  schematic.pdf, render.png — схема и вид платы
  Источник: https://gitlab.com/openflexure/sangaboard/sangaboard-rp2040 (папка jlcpcb)

2-plata-svetodioda — плата светодиода подсветки (ofm-led)
  gerber/      — Gerber-файлы панели из 6 плат (2 слоя, 78 × 83 мм, 1,6 мм)
  bom.csv, pos.csv — компоненты и координаты; светодиода Bridgelux BXEN-50S-11M-3C
                 и углового разъёма 1×2 (шаг 2,54) в списке нет — их нужно добавить
  Источник: https://gitlab.com/filipayazi/ofm-led (папка panel)

3-proshivka — прошивка для платы (заводу не нужна, прошьёте сами по README).

Лицензии — файлы LICENSE / License в папках (открытое оборудование CERN-OHL).
